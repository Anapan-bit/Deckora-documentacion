# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke\smoke.spec.js >> Smoke E2E — carga de la aplicación >> TC-E2E-001: la app carga en / sin errores de consola críticos
- Location: e2e\specs\smoke\smoke.spec.js:8:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.waitForLoadState: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation [ref=e4]:
      - link "DECKORA" [ref=e5] [cursor=pointer]:
        - /url: /
      - generic [ref=e6]:
        - link "Iniciar sesión" [ref=e7] [cursor=pointer]:
          - /url: /login
          - button "Iniciar sesión" [ref=e8]
        - link "Crear cuenta" [ref=e9] [cursor=pointer]:
          - /url: /registro
          - button "Crear cuenta" [ref=e10]
    - main [ref=e11]:
      - generic [ref=e13]:
        - generic [ref=e15]:
          - heading "DECKORA" [level=1] [ref=e16]
          - paragraph [ref=e17]: "La plataforma de Magic: The Gathering para la comunidad. Gestiona tus mazos, compite en torneos y conecta con tiendas locales."
          - generic [ref=e18]:
            - link "Crear cuenta" [ref=e19] [cursor=pointer]:
              - /url: /registro
            - link "Iniciar sesión" [ref=e20] [cursor=pointer]:
              - /url: /login
        - generic [ref=e21]:
          - heading "Todo lo que necesitas" [level=2] [ref=e22]
          - generic [ref=e23]:
            - generic [ref=e24]:
              - img [ref=e26]
              - heading "Gestiona tus mazos" [level=3] [ref=e30]
              - paragraph [ref=e31]: Construye, valida y comparte mazos de Commander con estadísticas detalladas.
            - generic [ref=e32]:
              - img [ref=e34]
              - heading "Compite en torneos" [level=3] [ref=e43]
              - paragraph [ref=e44]: Encuentra eventos cerca tuyo, inscríbete y registra tus partidas.
            - generic [ref=e45]:
              - img [ref=e47]
              - heading "Apoya tu tienda local" [level=3] [ref=e51]
              - paragraph [ref=e52]: Conecta con la comunidad y descubre tiendas de tu zona en el mapa.
            - generic [ref=e53]:
              - img [ref=e55]
              - heading "Asistente IA" [level=3] [ref=e58]
              - paragraph [ref=e59]: Recomendaciones inteligentes para mejorar tus mazos.
        - generic [ref=e60]:
          - heading "¿Cuál es tu rol?" [level=2] [ref=e61]
          - paragraph [ref=e62]: "Deckora se adapta a cómo participas en la comunidad de Magic: The Gathering."
          - generic [ref=e63]:
            - generic [ref=e64]:
              - generic [ref=e65]:
                - img [ref=e66]
                - heading "Jugador" [level=3] [ref=e69]
              - list [ref=e70]:
                - listitem [ref=e71]: — Crea y comparte mazos de Magic
                - listitem [ref=e72]: — Explora la biblioteca de cartas de Magic
                - listitem [ref=e73]: — Inscríbete en torneos locales
                - listitem [ref=e74]: — Consulta tus estadísticas de partidas
            - generic [ref=e75]:
              - generic [ref=e76]:
                - img [ref=e77]
                - heading "Organizador" [level=3] [ref=e79]
              - list [ref=e80]:
                - listitem [ref=e81]: — Crea y gestiona torneos
                - listitem [ref=e82]: — Administra inscripciones y rondas
                - listitem [ref=e83]: — Reporta resultados de partidas
                - listitem [ref=e84]: — Gestiona standings en tiempo real
            - generic [ref=e85]:
              - generic [ref=e86]:
                - img [ref=e87]
                - heading "Tienda" [level=3] [ref=e91]
              - list [ref=e92]:
                - listitem [ref=e93]: — Aparece en el mapa de tiendas
                - listitem [ref=e94]: — Organiza torneos en tu local
                - listitem [ref=e95]: — Conecta con jugadores de tu zona
                - listitem [ref=e96]: — Configura tu perfil de tienda
        - generic [ref=e98]:
          - generic [ref=e99]:
            - img [ref=e100]
            - heading "Tiendas en tu zona" [level=2] [ref=e103]
          - paragraph [ref=e105]: Encuentra eventos y comunidad cerca de ti.
          - generic [ref=e107]:
            - status "Cargando" [ref=e109]
            - generic [ref=e111]: Cargando mapa de tiendas...
        - generic [ref=e113]:
          - heading "Únete a la mesa" [level=2] [ref=e114]
          - paragraph [ref=e115]: Crea tu cuenta gratis y empieza a gestionar tus mazos, competir en torneos y conectar con la comunidad Commander.
          - link "Crear cuenta" [ref=e116] [cursor=pointer]:
            - /url: /registro
    - contentinfo [ref=e117]: © 2026 Deckora — TPY1101 Equipo 2
  - region "Notificaciones"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | // ═══════════════════════════════════════════════════════════════════════════
  4  | // TC-E2E-001 — Smoke: la aplicación carga sin errores de consola
  5  | // ═══════════════════════════════════════════════════════════════════════════
  6  | 
  7  | test.describe('Smoke E2E — carga de la aplicación', () => {
  8  |   test('TC-E2E-001: la app carga en / sin errores de consola críticos', async ({ page }) => {
  9  |     const errores = [];
  10 |     page.on('pageerror', (err) => errores.push(err.message));
  11 | 
  12 |     // Mock mínimo: evitar llamadas reales a Supabase al verificar sesión
  13 |     await page.route('**/auth/v1/session**', (route) =>
  14 |       route.fulfill({ status: 200, body: JSON.stringify({ data: { session: null }, error: null }) }),
  15 |     );
  16 |     await page.route('**/auth/v1/**', (route) =>
  17 |       route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({}) }),
  18 |     );
  19 | 
  20 |     await page.goto('/');
> 21 |     await page.waitForLoadState('networkidle');
     |                ^ Error: page.waitForLoadState: Test timeout of 30000ms exceeded.
  22 | 
  23 |     // La landing debe ser visible (el título principal o algún elemento de la UI)
  24 |     await expect(page.locator('body')).toBeVisible();
  25 | 
  26 |     // Sin errores JS críticos en la consola
  27 |     expect(errores).toHaveLength(0);
  28 |   });
  29 | });
  30 | 
```