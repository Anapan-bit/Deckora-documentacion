import { useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Dropdown, Offcanvas } from 'react-bootstrap';
import { Menu, LogOut, User, Settings } from 'lucide-react';

import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui';

const DASHBOARD_ITEMS = {
  jugador: [
    { to: '/mazos', label: 'Mis mazos' },
    { to: '/configuracion', label: 'Configuración' },
  ],
  organizador: [
    { to: '/mis-torneos', label: 'Mis torneos' },
    { to: '/organizador/torneos/nuevo', label: 'Crear torneo' },
    { to: '/configuracion', label: 'Configuración' },
  ],
  tienda: [
    { to: '/mis-torneos', label: 'Mis torneos' },
    { to: '/organizador/torneos/nuevo', label: 'Crear torneo' },
    { to: '/configuracion', label: 'Configuración' },
  ],
};

function getInitials(user) {
  const name = user?.nombre_usuario ?? user?.email ?? '?';
  return name.slice(0, 2).toUpperCase();
}

export default function Navbar() {
  const { user, rol, logout } = useAuth();
  const [showOffcanvas, setShowOffcanvas] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  const username = user?.nombre_usuario ?? user?.email?.split('@')[0] ?? '';

  const authLinks = (
    <>
      <li><NavLink to="/biblioteca" className="navbar-link">Biblioteca</NavLink></li>
      <li><NavLink to="/torneos" className="navbar-link">Torneos</NavLink></li>
      <li><NavLink to={`/${rol}`} className="navbar-link">Mi panel</NavLink></li>
    </>
  );

  return (
    <nav className="navbar-deckora">
      <Link to="/" className="navbar-logo">DECKORA</Link>

      {!isHome && user && (
        <ul className="navbar-links">
          {authLinks}
        </ul>
      )}

      <div className="navbar-actions">
        {user ? (
          <Dropdown align="end">
            <Dropdown.Toggle as="div" bsPrefix="none">
              <div className="navbar-avatar">{getInitials(user)}</div>
            </Dropdown.Toggle>
            <Dropdown.Menu className="dropdown-menu-deckora">
              <Dropdown.Item as={Link} to={`/u/${username}`} className="dropdown-item-deckora">
                <User size={14} /> Perfil
              </Dropdown.Item>
              <Dropdown.Item as={Link} to="/configuracion" className="dropdown-item-deckora">
                <Settings size={14} /> Configuración
              </Dropdown.Item>
              <Dropdown.Divider className="dropdown-divider-deckora" />
              <Dropdown.Item onClick={logout} className="dropdown-item-deckora dropdown-item-deckora--danger">
                <LogOut size={14} /> Cerrar sesión
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        ) : (
          <>
            <Link to="/login"><Button variant="ghost" size="sm">Iniciar sesión</Button></Link>
            <Link to="/registro"><Button variant="primary" size="sm">Crear cuenta</Button></Link>
          </>
        )}

        <button
          className="navbar-hamburger d-lg-none"
          onClick={() => setShowOffcanvas(true)}
          aria-label="Menú"
        >
          <Menu size={22} />
        </button>
      </div>

      <Offcanvas show={showOffcanvas} onHide={() => setShowOffcanvas(false)} placement="end" className="offcanvas-deckora">
        <Offcanvas.Header closeButton className="offcanvas-header-deckora">
          <Offcanvas.Title className="navbar-logo">DECKORA</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          {!isHome && user && (
            <>
              <ul className="offcanvas-nav">
                <li><NavLink to="/biblioteca" className="navbar-link" onClick={() => setShowOffcanvas(false)}>Biblioteca</NavLink></li>
                <li><NavLink to="/torneos" className="navbar-link" onClick={() => setShowOffcanvas(false)}>Torneos</NavLink></li>
                <li><NavLink to={`/${rol}`} className="navbar-link" onClick={() => setShowOffcanvas(false)}>Mi panel</NavLink></li>
              </ul>
              {rol && DASHBOARD_ITEMS[rol]?.length > 0 && (
                <>
                  <hr className="offcanvas-separator" />
                  <ul className="offcanvas-nav">
                    {DASHBOARD_ITEMS[rol].map(item => (
                      <li key={item.to}>
                        <NavLink
                          to={item.to}
                          className={({ isActive }) => `navbar-link${isActive ? ' navbar-link--active' : ''}`}
                          onClick={() => setShowOffcanvas(false)}
                        >
                          {item.label}
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </>
          )}
          {!user && (
            <div className="offcanvas-nav-actions">
              <Link to="/login" onClick={() => setShowOffcanvas(false)}><Button variant="ghost">Iniciar sesión</Button></Link>
              <Link to="/registro" onClick={() => setShowOffcanvas(false)}><Button variant="primary">Crear cuenta</Button></Link>
            </div>
          )}
        </Offcanvas.Body>
      </Offcanvas>
    </nav>
  );
}
