import supabase from '../config/supabase.js';
import { Usuario } from '../models/index.js';

export default async function auth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token no provisto' });
  }

  const token = authHeader.slice(7);

  let supabaseUser;
  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data?.user) {
      return res.status(401).json({ error: 'Token inválido' });
    }
    supabaseUser = data.user;
  } catch {
    return res.status(401).json({ error: 'Token inválido' });
  }

  const usuario = await Usuario.findByPk(supabaseUser.id);
  if (!usuario) {
    return res.status(401).json({
      error: 'Usuario autenticado pero no registrado en el sistema',
    });
  }

  if (!usuario.activo) {
    return res.status(401).json({ error: 'Cuenta desactivada' });
  }

  req.usuarioAuth = supabaseUser;
  req.usuario = usuario;
  next();
}
